# Basket Random Online — original export + multiplayer bridge

This package starts from the supplied `rz-6-5-z/bsrandm` Construct 3 HTML5 export. The original game files, assets, Box2D runtime and `data.json` are retained. The multiplayer layer is added outside the Construct event sheets.

## Architecture

- Player 1 / host runs the original Basket Random game at normal speed.
- Player 2 / guest connects over a WebSocket to the same Node server.
- Player 2 input is relayed to the host and drives the original `P2Control` global variable.
- The host sends snapshots of the original game's global state and important player/ball/visual objects about 15 times per second.
- The guest uses the original Construct export as a render replica while paused, so it displays the host's actual game state instead of running a second independent physics simulation.
- The original Construct/Box2D game logic is not replaced with a new basketball game.

## Deploy on Render

Create a **Web Service** from this package/repository.

Build command:

`npm install`

Start command:

`npm start`

Render supplies `PORT` automatically. The browser connects to the same origin with `wss://` when the site is HTTPS.

## Play

1. Open the Render URL on iPad 1.
2. Tap **CREATE ROOM**.
3. Copy the 4-digit code.
4. Open the same Render URL on iPad 2.
5. Tap **JOIN ROOM**, enter the code, and join.
6. On iPad 1, use the original Basket Random menu/start controls.
7. Player 1's control area is the lower-left side. Player 2's is the lower-right side.

## Local test

On a computer with Node installed:

`npm install`

`npm start`

Then open `http://localhost:10000/` in two browser windows. For iPad testing, use the Render HTTPS URL so the connection is WSS.

## Notes

The network connection is implemented with a WebSocket relay because it is much simpler to deploy and test on iPads than a separate WebRTC signaling/TURN stack. It is suitable for a 2-player test, although a future production version could move the same protocol to WebRTC if desired.

The supplied Construct export originally referenced its worker/runtime scripts from jsDelivr. This package points those three worker/runtime references to the local copies included in the ZIP so the game is more self-contained.
