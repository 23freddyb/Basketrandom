/*
  Basket Random Online Multiplayer bridge
  Built around the supplied Construct 3 export.
  - Host runs the real game at normal speed.
  - Guest uses the real game as a render replica (timeScale 0) and receives host snapshots.
  - Both devices retain the original Construct game logic, assets and Box2D runtime.
*/
(() => {
  "use strict";

  const $ = id => document.getElementById(id);
  const lobby = $("br-lobby");
  const card = $("br-card");
  const createBtn = $("br-create");
  const joinShowBtn = $("br-join-show");
  const joinRow = $("br-join-row");
  const codeInput = $("br-code");
  const joinBtn = $("br-join");
  const statusEl = $("br-status");
  const roleEl = $("br-role");
  const controls = $("br-controls");
  const p1Zone = $("br-p1-zone");
  const p2Zone = $("br-p2-zone");
  const guestBlock = $("br-guest-block");
  const guestControl = $("br-guest-control");
  const pill = $("br-pill");

  const GLOBAL_VARS = [
    "angularMaxRND","angularMinRND","wooble","angularSub","snowSlip",
    "P1Control","P2Control","p1Score","p2Score","goal","CPU","biz"
  ];

  // Dynamic/visual object classes present in the supplied export.
  const SYNC_OBJECTS = [
    "body","head","body2","head2","body3","head3","body4","head4",
    "arm","arm2","arm3","arm4","armBiz","rightShoe","rightShort","hair","tshirt","skin",
    "player","playerLine","headLine","line","scoreBG","fontWonder","font",
    "normalBall","kamesBall","heavyBall","smallBall","balls","ballLine","ballShadow","ballCol",
    "potaP","potaP2","potaSprite","potaCollision","potaBack","potaShadow","potaFile",
    "p1Collision","p2Collision","p3Collision","p4Collision","handCollision","handCollision2","handCollision3","handCollision4",
    "scoreCollision","snowParticle","shark","tutorial","pauseButtons","startButton","startButton2","startButtons"
  ];

  // Physics-bearing classes; authoritative snapshots include velocity where available.
  const PHYSICS_OBJECTS = new Set([
    "body","head","body2","head2","body3","head3","body4","head4",
    "normalBall","kamesBall","heavyBall","smallBall","balls","potaP","potaP2"
  ]);

  let ws = null;
  let role = "";
  let room = "";
  let runtime = null;
  let connected = false;
  let ready = false;
  let hostReady = false;
  let guestReady = false;
  let applyingRemote = false;
  let snapshotTimer = 0;
  let lastSnapshot = null;
  let layoutPending = null;
  let currentRoleInput = null;

  function setStatus(msg, error = false) {
    statusEl.textContent = msg;
    statusEl.style.color = error ? "#ff8b8b" : "#fff";
  }

  function showLobby(show) {
    lobby.style.display = show ? "flex" : "none";
  }

  function showRoleControls() {
    controls.style.display = "block";
    pill.style.display = "block";
    pill.textContent = role === "host" ? "PLAYER 1 • HOST" : "PLAYER 2 • ONLINE";
    if (role === "guest") {
      guestBlock.style.display = "block";
      guestControl.style.display = "block";
      p1Zone.style.display = "none";
      p2Zone.style.display = "none";
    } else {
      guestBlock.style.display = "none";
      guestControl.style.display = "none";
      p1Zone.style.display = "block";
      p2Zone.style.display = "none";
    }
  }

  function getRuntime() {
    try {
      const iface = window.c3_runtimeInterface;
      if (iface && typeof iface.g_aYv === "function") return iface.g_aYv();
    } catch (_) {}
    return null;
  }

  function setGlobal(name, value) {
    if (!runtime || !runtime.globalVars) return;
    if (Object.prototype.hasOwnProperty.call(runtime.globalVars, name)) {
      runtime.globalVars[name] = value;
    }
  }

  function getText(inst) {
    try { return typeof inst.text === "string" ? inst.text : undefined; } catch (_) { return undefined; }
  }

  function captureObjectClass(name) {
    if (!runtime || !runtime.objects) return null;
    const cls = runtime.objects[name];
    if (!cls || typeof cls.instances !== "function") return null;
    const out = [];
    let instances = [];
    try { instances = cls.instances(); } catch (_) { return null; }
    for (const inst of instances) {
      const rec = {
        x: typeof inst.x === "number" ? inst.x : undefined,
        y: typeof inst.y === "number" ? inst.y : undefined,
        angle: typeof inst.angle === "number" ? inst.angle : undefined,
        opacity: typeof inst.opacity === "number" ? inst.opacity : undefined,
        visible: typeof inst.isVisible === "boolean" ? inst.isVisible : undefined,
        width: typeof inst.width === "number" ? inst.width : undefined,
        height: typeof inst.height === "number" ? inst.height : undefined,
        zIndex: typeof inst.zIndex === "number" ? inst.zIndex : undefined
      };
      try {
        if (inst.instVars && Object.prototype.hasOwnProperty.call(inst.instVars, "which")) rec.which = inst.instVars.which;
      } catch (_) {}
      try {
        if (typeof inst.animationName === "string") rec.anim = inst.animationName;
        if (typeof inst.animationFrame === "number") rec.frame = inst.animationFrame;
      } catch (_) {}
      const txt = getText(inst);
      if (txt !== undefined) rec.text = txt;
      if (PHYSICS_OBJECTS.has(name)) {
        try {
          const ph = inst.behaviors && inst.behaviors.Physics;
          if (ph) {
            rec.v = ph.getVelocity ? ph.getVelocity() : [ph.getVelocityX?.(), ph.getVelocityY?.()];
            rec.av = typeof ph.angularVelocity === "number" ? ph.angularVelocity : undefined;
          }
        } catch (_) {}
      }
      out.push(rec);
    }
    return out;
  }

  function captureSnapshot() {
    if (!runtime) return null;
    const snap = {
      t: Date.now(),
      layout: runtime.layout ? runtime.layout.name : "",
      globals: {},
      objects: {}
    };
    for (const name of GLOBAL_VARS) {
      try { snap.globals[name] = runtime.globalVars[name]; } catch (_) {}
    }
    for (const name of SYNC_OBJECTS) {
      const data = captureObjectClass(name);
      if (data && data.length) snap.objects[name] = data;
    }
    return snap;
  }

  function setObjectRecord(inst, rec, name) {
    if (rec.x !== undefined) inst.x = rec.x;
    if (rec.y !== undefined) inst.y = rec.y;
    if (rec.angle !== undefined) inst.angle = rec.angle;
    if (rec.opacity !== undefined) inst.opacity = rec.opacity;
    if (rec.visible !== undefined && typeof inst.isVisible === "boolean") inst.isVisible = rec.visible;
    if (rec.width !== undefined) inst.width = rec.width;
    if (rec.height !== undefined) inst.height = rec.height;
    try {
      if (inst.animationName !== undefined && rec.anim !== undefined) inst.animationName = rec.anim;
      if (inst.animationFrame !== undefined && rec.frame !== undefined) inst.animationFrame = rec.frame;
    } catch (_) {}
    try {
      if (inst.text !== undefined && rec.text !== undefined) inst.text = rec.text;
    } catch (_) {}
    if (PHYSICS_OBJECTS.has(name) && rec.v && inst.behaviors && inst.behaviors.Physics) {
      try {
        inst.behaviors.Physics.setVelocity(rec.v[0] || 0, rec.v[1] || 0);
        if (rec.av !== undefined) inst.behaviors.Physics.angularVelocity = rec.av;
      } catch (_) {}
    }
  }

  function applySnapshot(snap) {
    if (!runtime || !snap) return;
    if (snap.layout && runtime.layout && runtime.layout.name.toLowerCase() !== snap.layout.toLowerCase()) {
      layoutPending = snap;
      try { runtime.goToLayout(snap.layout); } catch (_) {}
      return;
    }
    applyingRemote = true;
    try {
      for (const [name, value] of Object.entries(snap.globals || {})) setGlobal(name, value);
      for (const [name, list] of Object.entries(snap.objects || {})) {
        const cls = runtime.objects[name];
        if (!cls || typeof cls.instances !== "function") continue;
        let instances = [];
        try { instances = cls.instances(); } catch (_) { continue; }
        const count = Math.min(instances.length, list.length);
        for (let i = 0; i < count; i++) setObjectRecord(instances[i], list[i], name);
      }
    } finally {
      applyingRemote = false;
    }
    lastSnapshot = snap;
  }

  function announceReady() {
    if (!connected || ready) return;
    ready = true;
    send({ type: "ready" });
  }

  function startGameReplica() {
    if (!runtime) return;
    if (role === "guest") runtime.timeScale = 0;
    else runtime.timeScale = 1;
    showLobby(false);
    showRoleControls();
  }

  function send(obj) {
    if (!ws || ws.readyState !== WebSocket.OPEN) return false;
    try { ws.send(JSON.stringify(obj)); return true; } catch (_) { return false; }
  }

  function connectServer() {
    const explicit = new URLSearchParams(location.search).get("server");
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    const url = explicit || `${proto}//${location.host}`;
    setStatus(`Connecting to game server…\n${url}`);
    try { ws = new WebSocket(url); }
    catch (e) { setStatus(`Connection error: ${e.message}`, true); return; }

    ws.addEventListener("open", () => {
      connected = true;
      setStatus("Connected. Choose CREATE ROOM or JOIN ROOM.");
    });
    ws.addEventListener("close", () => {
      connected = false;
      ready = false;
      if (role) setStatus("Disconnected from game server.", true);
    });
    ws.addEventListener("error", () => {
      setStatus("Connection error. The game server must support WSS/HTTPS.", true);
    });
    ws.addEventListener("message", ev => {
      let m; try { m = JSON.parse(ev.data); } catch (_) { return; }
      switch (m.type) {
        case "created":
          role = "host"; room = m.room;
          roleEl.textContent = `ROOM CODE: ${room}`;
          setStatus("Give this code to Player 2. Waiting for the second iPad…");
          createBtn.disabled = true; joinShowBtn.disabled = true;
          break;
        case "joined":
          role = "guest"; room = m.room;
          roleEl.textContent = `ROOM CODE: ${room}`;
          setStatus("Joined. Waiting for Player 1 to start…");
          createBtn.disabled = true; joinShowBtn.disabled = true; joinRow.style.display = "none";
          break;
        case "playerJoined":
          if (role === "host") setStatus(`ROOM CODE: ${room}\nPlayer 2 connected. Starting multiplayer…`);
          break;
        case "start":
          hostReady = true; guestReady = true;
          startGameReplica();
          break;
        case "input":
          if (role === "host") setGlobal(m.name, m.value);
          break;
        case "snapshot":
          if (role === "guest") applySnapshot(m.snapshot);
          break;
        case "error":
          setStatus(m.message || "Server error", true);
          break;
        case "peerLeft":
          setStatus("Player 2 disconnected. Create a new room to play again.", true);
          break;
      }
    });
  }

  function sendInput(name, value) {
    if (applyingRemote || role !== "guest") return;
    // Guest controls Player 2 only.
    setGlobal(name, value);
    send({ type: "input", name, value });
  }

  function bindTouchZone(zone, varName) {
    const down = e => {
      e.preventDefault();
      if (currentRoleInput) return;
      currentRoleInput = e.pointerId ?? "touch";
      sendInput(varName, 5);
    };
    const up = e => {
      e.preventDefault();
      if (currentRoleInput !== (e.pointerId ?? "touch")) return;
      currentRoleInput = null;
      sendInput(varName, 4);
    };
    ["pointerdown","touchstart"].forEach(type => zone.addEventListener(type, down, { passive:false }));
    ["pointerup","pointercancel","touchend","touchcancel","mouseleave"].forEach(type => zone.addEventListener(type, up, { passive:false }));
  }

  function bindHostTouchZone() {
    let down = false;
    const press = e => { if (role !== "host") return; e.preventDefault(); down = true; setGlobal("P1Control", 5); };
    const release = e => { if (!down) return; e.preventDefault(); down = false; setGlobal("P1Control", 4); };
    ["pointerdown","touchstart"].forEach(t => p1Zone.addEventListener(t, press, {passive:false}));
    ["pointerup","pointercancel","touchend","touchcancel","mouseleave"].forEach(t => p1Zone.addEventListener(t, release, {passive:false}));
    window.addEventListener("blur", () => { down=false; if(role==="host") setGlobal("P1Control",4); });
  }

  function waitForRuntime() {
    runtime = getRuntime();
    if (runtime) {
      try {
        runtime.addEventListener("afteranylayoutstart", () => {
          if (layoutPending) {
            const snap = layoutPending;
            layoutPending = null;
            setTimeout(() => applySnapshot(snap), 0);
          }
        });
      } catch (_) {}
      // Hold the original game until the room has two players.
      try { runtime.timeScale = 0; } catch (_) {}
      announceReady();
    } else {
      setTimeout(waitForRuntime, 150);
    }
  }

  function heartbeat() {
    if (!runtime || role !== "host" || !ws || ws.readyState !== WebSocket.OPEN || !hostReady) return;
    const snap = captureSnapshot();
    if (snap) send({ type: "snapshot", snapshot: snap });
  }

  createBtn.addEventListener("click", () => {
    if (!connected) { setStatus("Not connected to the game server yet.", true); return; }
    setStatus("Creating room…");
    send({ type: "create" });
  });

  joinShowBtn.addEventListener("click", () => {
    joinRow.style.display = "block";
    codeInput.focus();
  });

  joinBtn.addEventListener("click", () => {
    if (!connected) { setStatus("Not connected to the game server yet.", true); return; }
    const code = codeInput.value.replace(/\D/g, "").slice(0,4);
    if (code.length !== 4) { setStatus("Enter the 4-digit room code.", true); return; }
    setStatus(`Joining room ${code}…`);
    send({ type: "join", room: code });
  });

  codeInput.addEventListener("input", () => { codeInput.value = codeInput.value.replace(/\D/g, "").slice(0,4); });
  window.addEventListener("beforeunload", () => { try { ws?.close(); } catch (_) {} });

  bindHostTouchZone();
  // The guest's P2 button drives the same original global variable the game's controls use.
  bindTouchZone(guestControl, "P2Control");

  // Host snapshots at ~15 Hz; guest applies on arrival.
  snapshotTimer = window.setInterval(heartbeat, 66);

  // Keep local guest display from accidentally receiving gameplay taps outside its control zone.
  guestBlock.addEventListener("pointerdown", e => e.preventDefault(), {passive:false});
  guestBlock.addEventListener("pointerup", e => e.preventDefault(), {passive:false});

  connectServer();
  waitForRuntime();
})();
