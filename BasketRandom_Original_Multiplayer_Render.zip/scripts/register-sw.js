// Multiplayer build: service workers intentionally disabled to prevent stale cached game scripts.
